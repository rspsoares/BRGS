﻿namespace BRGS.UI
{
    partial class mdiBRGS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mdiBRGS));
            this.ribbon1 = new System.Windows.Forms.Ribbon();
            this.rtFinanceiro = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel1 = new System.Windows.Forms.RibbonPanel();
            this.rbFinanceiro_NFConsulta = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator1 = new System.Windows.Forms.RibbonSeparator();
            this.ribbonButton1 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator2 = new System.Windows.Forms.RibbonSeparator();
            this.rbFinanceiro_NFEmissao = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator5 = new System.Windows.Forms.RibbonSeparator();
            this.rbFinanceiro_NFRelatorio = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel4 = new System.Windows.Forms.RibbonPanel();
            this.rbFinanceiro_OPConsulta = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator10 = new System.Windows.Forms.RibbonSeparator();
            this.rbFinanceiro_OPRelatorio = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator12 = new System.Windows.Forms.RibbonSeparator();
            this.rbFinanceiro_RelatorioGastos = new System.Windows.Forms.RibbonButton();
            this.ribbonTab2 = new System.Windows.Forms.RibbonTab();
            this.rtEngenharia = new System.Windows.Forms.RibbonTab();
            this.rpEngenharia_Cadastros = new System.Windows.Forms.RibbonPanel();
            this.rbEngenharia_Despesas = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator3 = new System.Windows.Forms.RibbonSeparator();
            this.rbEngenharia_CentrosCustos = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator4 = new System.Windows.Forms.RibbonSeparator();
            this.rbEngenharia_UEN = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator9 = new System.Windows.Forms.RibbonSeparator();
            this.rbEngenharia_Fases = new System.Windows.Forms.RibbonButton();
            this.rpEngenharia_LancamentoGastos = new System.Windows.Forms.RibbonPanel();
            this.rbEngenharia_Obras_Consulta = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator6 = new System.Windows.Forms.RibbonSeparator();
            this.rbEngenharia_Obras_Relatorio = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel5 = new System.Windows.Forms.RibbonPanel();
            this.rbTransporte_Veiculo = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator14 = new System.Windows.Forms.RibbonSeparator();
            this.rbTransporte_Motorista = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel6 = new System.Windows.Forms.RibbonPanel();
            this.rbTransporte_Abastecimento = new System.Windows.Forms.RibbonButton();
            this.rpTransporte_Frete = new System.Windows.Forms.RibbonPanel();
            this.rbTransporte_Frete = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator15 = new System.Windows.Forms.RibbonSeparator();
            this.rbTransporte_FreteRelatorio = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel8 = new System.Windows.Forms.RibbonPanel();
            this.rbTransporte_Manutencao = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel9 = new System.Windows.Forms.RibbonPanel();
            this.rbTransporte_Multa = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator16 = new System.Windows.Forms.RibbonSeparator();
            this.rbTransporte_Gravidade = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator17 = new System.Windows.Forms.RibbonSeparator();
            this.rbTransporte_Ocorrencia = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel10 = new System.Windows.Forms.RibbonPanel();
            this.rbTransporte_Uso = new System.Windows.Forms.RibbonButton();
            this.rtAdministrativo = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel3 = new System.Windows.Forms.RibbonPanel();
            this.rbAdministrativo_Clientes = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator7 = new System.Windows.Forms.RibbonSeparator();
            this.rbAdministrativo_Fornecedores = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator13 = new System.Windows.Forms.RibbonSeparator();
            this.rbAdministrativo_Atividades = new System.Windows.Forms.RibbonButton();
            this.ribbonButton2 = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator8 = new System.Windows.Forms.RibbonSeparator();
            this.rbAdministrativo_Categorias = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator11 = new System.Windows.Forms.RibbonSeparator();
            this.rbAdministrativo_Feriados = new System.Windows.Forms.RibbonButton();
            this.ribbonSeparator18 = new System.Windows.Forms.RibbonSeparator();
            this.rbAdministrativo_Empresa = new System.Windows.Forms.RibbonButton();
            this.rtSeguranca = new System.Windows.Forms.RibbonTab();
            this.ribbonPanel2 = new System.Windows.Forms.RibbonPanel();
            this.rbSeguranca_Usuarios = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel7 = new System.Windows.Forms.RibbonPanel();
            this.rbSeguranca_Auditoria = new System.Windows.Forms.RibbonButton();
            this.ribbonPanel11 = new System.Windows.Forms.RibbonPanel();
            this.rbSeguranca_Parametrizacao = new System.Windows.Forms.RibbonButton();
            this.tabTelas = new System.Windows.Forms.TabControl();
            this.atividadeCarregarComponenteCrystal = new System.ComponentModel.BackgroundWorker();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.tsUsuario = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // ribbon1
            // 
            this.ribbon1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ribbon1.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.Minimized = false;
            this.ribbon1.Name = "ribbon1";
            // 
            // 
            // 
            this.ribbon1.OrbDropDown.BorderRoundness = 8;
            this.ribbon1.OrbDropDown.Location = new System.Drawing.Point(0, 0);
            this.ribbon1.OrbDropDown.Name = "";
            this.ribbon1.OrbDropDown.Size = new System.Drawing.Size(527, 72);
            this.ribbon1.OrbDropDown.TabIndex = 0;
            this.ribbon1.OrbImage = null;
            this.ribbon1.OrbVisible = false;
            this.ribbon1.Size = new System.Drawing.Size(1237, 135);
            this.ribbon1.TabIndex = 2;
            this.ribbon1.Tabs.Add(this.rtFinanceiro);
            this.ribbon1.Tabs.Add(this.ribbonTab2);
            this.ribbon1.Tabs.Add(this.rtEngenharia);
            this.ribbon1.Tabs.Add(this.rtAdministrativo);
            this.ribbon1.Tabs.Add(this.rtSeguranca);
            this.ribbon1.TabsMargin = new System.Windows.Forms.Padding(12, 26, 20, 0);
            this.ribbon1.Text = "ribbon1";
            // 
            // rtFinanceiro
            // 
            this.rtFinanceiro.Panels.Add(this.ribbonPanel1);
            this.rtFinanceiro.Panels.Add(this.ribbonPanel4);
            this.rtFinanceiro.Text = "Financeiro";
            // 
            // ribbonPanel1
            // 
            this.ribbonPanel1.Items.Add(this.rbFinanceiro_NFConsulta);
            this.ribbonPanel1.Items.Add(this.ribbonSeparator2);
            this.ribbonPanel1.Items.Add(this.rbFinanceiro_NFEmissao);
            this.ribbonPanel1.Items.Add(this.ribbonSeparator5);
            this.ribbonPanel1.Items.Add(this.rbFinanceiro_NFRelatorio);
            this.ribbonPanel1.Text = "Notas Fiscais";
            // 
            // rbFinanceiro_NFConsulta
            // 
            this.rbFinanceiro_NFConsulta.DropDownItems.Add(this.ribbonSeparator1);
            this.rbFinanceiro_NFConsulta.DropDownItems.Add(this.ribbonButton1);
            this.rbFinanceiro_NFConsulta.Image = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_NFConsulta.Image")));
            this.rbFinanceiro_NFConsulta.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_NFConsulta.SmallImage")));
            this.rbFinanceiro_NFConsulta.Text = "Consulta";
            this.rbFinanceiro_NFConsulta.ToolTip = "";
            this.rbFinanceiro_NFConsulta.Value = "rbFinanceiro_NFConsulta";
            this.rbFinanceiro_NFConsulta.Click += new System.EventHandler(this.rbFinanceiro_NFConsulta_Click);
            // 
            // ribbonButton1
            // 
            this.ribbonButton1.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.Image")));
            this.ribbonButton1.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton1.SmallImage")));
            this.ribbonButton1.Text = "ribbonButton1";
            // 
            // rbFinanceiro_NFEmissao
            // 
            this.rbFinanceiro_NFEmissao.Image = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_NFEmissao.Image")));
            this.rbFinanceiro_NFEmissao.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_NFEmissao.SmallImage")));
            this.rbFinanceiro_NFEmissao.Text = "Emissão";
            this.rbFinanceiro_NFEmissao.ToolTip = "";
            this.rbFinanceiro_NFEmissao.Value = "rbFinanceiro_NFEmissao";
            this.rbFinanceiro_NFEmissao.Click += new System.EventHandler(this.rbFinanceiro_NFEmissao_Click);
            // 
            // rbFinanceiro_NFRelatorio
            // 
            this.rbFinanceiro_NFRelatorio.Image = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_NFRelatorio.Image")));
            this.rbFinanceiro_NFRelatorio.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_NFRelatorio.SmallImage")));
            this.rbFinanceiro_NFRelatorio.Text = "Relatório";
            this.rbFinanceiro_NFRelatorio.Value = "rbFinanceiro_NFRelatorio";
            this.rbFinanceiro_NFRelatorio.Click += new System.EventHandler(this.rbFinanceiro_NFRelatorio_Click);
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.Items.Add(this.rbFinanceiro_OPConsulta);
            this.ribbonPanel4.Items.Add(this.ribbonSeparator10);
            this.ribbonPanel4.Items.Add(this.rbFinanceiro_OPRelatorio);
            this.ribbonPanel4.Items.Add(this.ribbonSeparator12);
            this.ribbonPanel4.Items.Add(this.rbFinanceiro_RelatorioGastos);
            this.ribbonPanel4.Text = "Ordem de Pagamento";
            // 
            // rbFinanceiro_OPConsulta
            // 
            this.rbFinanceiro_OPConsulta.Image = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_OPConsulta.Image")));
            this.rbFinanceiro_OPConsulta.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_OPConsulta.SmallImage")));
            this.rbFinanceiro_OPConsulta.Text = "Consulta";
            this.rbFinanceiro_OPConsulta.Value = "rbFinanceiro_OPConsulta";
            this.rbFinanceiro_OPConsulta.Click += new System.EventHandler(this.rbFinanceiro_OPConsulta_Click);
            // 
            // rbFinanceiro_OPRelatorio
            // 
            this.rbFinanceiro_OPRelatorio.Image = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_OPRelatorio.Image")));
            this.rbFinanceiro_OPRelatorio.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_OPRelatorio.SmallImage")));
            this.rbFinanceiro_OPRelatorio.Text = "Relatório OP";
            this.rbFinanceiro_OPRelatorio.Value = "rbFinanceiro_OPRelatorio";
            this.rbFinanceiro_OPRelatorio.Click += new System.EventHandler(this.rbFinanceiro_OPRelatorio_Click);
            // 
            // rbFinanceiro_RelatorioGastos
            // 
            this.rbFinanceiro_RelatorioGastos.Image = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_RelatorioGastos.Image")));
            this.rbFinanceiro_RelatorioGastos.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbFinanceiro_RelatorioGastos.SmallImage")));
            this.rbFinanceiro_RelatorioGastos.Text = "Relatório Gastos";
            this.rbFinanceiro_RelatorioGastos.Value = "rbFinanceiro_RelatorioGastos";
            this.rbFinanceiro_RelatorioGastos.Click += new System.EventHandler(this.rbFinanceiro_RelatorioGastos_Click);
            // 
            // ribbonTab2
            // 
            this.ribbonTab2.Text = null;
            // 
            // rtEngenharia
            // 
            this.rtEngenharia.Panels.Add(this.rpEngenharia_Cadastros);
            this.rtEngenharia.Panels.Add(this.rpEngenharia_LancamentoGastos);
            this.rtEngenharia.Panels.Add(this.ribbonPanel5);
            this.rtEngenharia.Panels.Add(this.ribbonPanel6);
            this.rtEngenharia.Panels.Add(this.rpTransporte_Frete);
            this.rtEngenharia.Panels.Add(this.ribbonPanel8);
            this.rtEngenharia.Panels.Add(this.ribbonPanel9);
            this.rtEngenharia.Panels.Add(this.ribbonPanel10);
            this.rtEngenharia.Text = "Operações";
            // 
            // rpEngenharia_Cadastros
            // 
            this.rpEngenharia_Cadastros.Items.Add(this.rbEngenharia_Despesas);
            this.rpEngenharia_Cadastros.Items.Add(this.ribbonSeparator3);
            this.rpEngenharia_Cadastros.Items.Add(this.rbEngenharia_CentrosCustos);
            this.rpEngenharia_Cadastros.Items.Add(this.ribbonSeparator4);
            this.rpEngenharia_Cadastros.Items.Add(this.rbEngenharia_UEN);
            this.rpEngenharia_Cadastros.Items.Add(this.ribbonSeparator9);
            this.rpEngenharia_Cadastros.Items.Add(this.rbEngenharia_Fases);
            this.rpEngenharia_Cadastros.Text = "Cadastros";
            // 
            // rbEngenharia_Despesas
            // 
            this.rbEngenharia_Despesas.Image = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_Despesas.Image")));
            this.rbEngenharia_Despesas.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_Despesas.SmallImage")));
            this.rbEngenharia_Despesas.Text = "Despesas";
            this.rbEngenharia_Despesas.Value = "rbEngenharia_Despesas";
            this.rbEngenharia_Despesas.Click += new System.EventHandler(this.rbEngenharia_Despesas_Click);
            // 
            // rbEngenharia_CentrosCustos
            // 
            this.rbEngenharia_CentrosCustos.Image = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_CentrosCustos.Image")));
            this.rbEngenharia_CentrosCustos.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_CentrosCustos.SmallImage")));
            this.rbEngenharia_CentrosCustos.Text = "Centros Custos";
            this.rbEngenharia_CentrosCustos.Value = "rbEngenharia_CentrosCustos";
            this.rbEngenharia_CentrosCustos.Click += new System.EventHandler(this.rbEngenharia_CentrosCustos_Click);
            // 
            // rbEngenharia_UEN
            // 
            this.rbEngenharia_UEN.Image = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_UEN.Image")));
            this.rbEngenharia_UEN.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_UEN.SmallImage")));
            this.rbEngenharia_UEN.Text = "UEN";
            this.rbEngenharia_UEN.Value = "rbEngenharia_UEN";
            this.rbEngenharia_UEN.Click += new System.EventHandler(this.rbEngenharia_UEN_Click);
            // 
            // rbEngenharia_Fases
            // 
            this.rbEngenharia_Fases.Image = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_Fases.Image")));
            this.rbEngenharia_Fases.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_Fases.SmallImage")));
            this.rbEngenharia_Fases.Text = "Fases";
            this.rbEngenharia_Fases.Value = "rbEngenharia_Fases";
            this.rbEngenharia_Fases.Click += new System.EventHandler(this.rbEngenharia_Fases_Click);
            // 
            // rpEngenharia_LancamentoGastos
            // 
            this.rpEngenharia_LancamentoGastos.Items.Add(this.rbEngenharia_Obras_Consulta);
            this.rpEngenharia_LancamentoGastos.Items.Add(this.ribbonSeparator6);
            this.rpEngenharia_LancamentoGastos.Items.Add(this.rbEngenharia_Obras_Relatorio);
            this.rpEngenharia_LancamentoGastos.Text = "Obras";
            // 
            // rbEngenharia_Obras_Consulta
            // 
            this.rbEngenharia_Obras_Consulta.Image = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_Obras_Consulta.Image")));
            this.rbEngenharia_Obras_Consulta.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_Obras_Consulta.SmallImage")));
            this.rbEngenharia_Obras_Consulta.Text = "Consulta";
            this.rbEngenharia_Obras_Consulta.Value = "rbEngenharia_Obras_Consulta";
            this.rbEngenharia_Obras_Consulta.Click += new System.EventHandler(this.rbEngenharia_Obras_Consulta_Click);
            // 
            // rbEngenharia_Obras_Relatorio
            // 
            this.rbEngenharia_Obras_Relatorio.Image = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_Obras_Relatorio.Image")));
            this.rbEngenharia_Obras_Relatorio.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbEngenharia_Obras_Relatorio.SmallImage")));
            this.rbEngenharia_Obras_Relatorio.Text = "Relatório";
            this.rbEngenharia_Obras_Relatorio.Value = "rbEngenharia_Obras_Relatorio";
            this.rbEngenharia_Obras_Relatorio.Click += new System.EventHandler(this.rbEngenharia_Obras_Relatorio_Click);
            // 
            // ribbonPanel5
            // 
            this.ribbonPanel5.Items.Add(this.rbTransporte_Veiculo);
            this.ribbonPanel5.Items.Add(this.ribbonSeparator14);
            this.ribbonPanel5.Items.Add(this.rbTransporte_Motorista);
            this.ribbonPanel5.Text = "Cadastros";
            // 
            // rbTransporte_Veiculo
            // 
            this.rbTransporte_Veiculo.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Veiculo.Image")));
            this.rbTransporte_Veiculo.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Veiculo.SmallImage")));
            this.rbTransporte_Veiculo.Text = "Veículos";
            this.rbTransporte_Veiculo.Value = "rbTransporte_Veiculo";
            this.rbTransporte_Veiculo.Click += new System.EventHandler(this.rbTransporte_Veiculo_Click);
            // 
            // rbTransporte_Motorista
            // 
            this.rbTransporte_Motorista.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Motorista.Image")));
            this.rbTransporte_Motorista.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Motorista.SmallImage")));
            this.rbTransporte_Motorista.Text = "Motoristas";
            this.rbTransporte_Motorista.Value = "rbTransporte_Motorista";
            this.rbTransporte_Motorista.Click += new System.EventHandler(this.rbTransporte_Motorista_Click);
            // 
            // ribbonPanel6
            // 
            this.ribbonPanel6.Items.Add(this.rbTransporte_Abastecimento);
            this.ribbonPanel6.Text = "Abastecimentos";
            // 
            // rbTransporte_Abastecimento
            // 
            this.rbTransporte_Abastecimento.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Abastecimento.Image")));
            this.rbTransporte_Abastecimento.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Abastecimento.SmallImage")));
            this.rbTransporte_Abastecimento.Text = "Controle";
            this.rbTransporte_Abastecimento.Value = "rbTransporte_Abastecimento";
            this.rbTransporte_Abastecimento.Click += new System.EventHandler(this.rbTransporte_Abastecimento_Click);
            // 
            // rpTransporte_Frete
            // 
            this.rpTransporte_Frete.Items.Add(this.rbTransporte_Frete);
            this.rpTransporte_Frete.Items.Add(this.ribbonSeparator15);
            this.rpTransporte_Frete.Items.Add(this.rbTransporte_FreteRelatorio);
            this.rpTransporte_Frete.Text = "Frete";
            // 
            // rbTransporte_Frete
            // 
            this.rbTransporte_Frete.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Frete.Image")));
            this.rbTransporte_Frete.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Frete.SmallImage")));
            this.rbTransporte_Frete.Text = "Controle";
            this.rbTransporte_Frete.Value = "rbTransporte_Frete";
            this.rbTransporte_Frete.Click += new System.EventHandler(this.rbTransporte_Frete_Click);
            // 
            // rbTransporte_FreteRelatorio
            // 
            this.rbTransporte_FreteRelatorio.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_FreteRelatorio.Image")));
            this.rbTransporte_FreteRelatorio.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_FreteRelatorio.SmallImage")));
            this.rbTransporte_FreteRelatorio.Text = "Relatório";
            this.rbTransporte_FreteRelatorio.Value = "rbTransporte_FreteRelatorio";
            this.rbTransporte_FreteRelatorio.Click += new System.EventHandler(this.rbTransporte_FreteRelatorio_Click);
            // 
            // ribbonPanel8
            // 
            this.ribbonPanel8.Items.Add(this.rbTransporte_Manutencao);
            this.ribbonPanel8.Text = "Manutenção";
            // 
            // rbTransporte_Manutencao
            // 
            this.rbTransporte_Manutencao.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Manutencao.Image")));
            this.rbTransporte_Manutencao.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Manutencao.SmallImage")));
            this.rbTransporte_Manutencao.Text = "Controle";
            this.rbTransporte_Manutencao.Value = "rbTransporte_Manutencao";
            this.rbTransporte_Manutencao.Click += new System.EventHandler(this.rbTransporte_Manutencao_Click);
            // 
            // ribbonPanel9
            // 
            this.ribbonPanel9.Items.Add(this.rbTransporte_Multa);
            this.ribbonPanel9.Items.Add(this.ribbonSeparator16);
            this.ribbonPanel9.Items.Add(this.rbTransporte_Gravidade);
            this.ribbonPanel9.Items.Add(this.ribbonSeparator17);
            this.ribbonPanel9.Items.Add(this.rbTransporte_Ocorrencia);
            this.ribbonPanel9.Text = "Multas";
            // 
            // rbTransporte_Multa
            // 
            this.rbTransporte_Multa.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Multa.Image")));
            this.rbTransporte_Multa.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Multa.SmallImage")));
            this.rbTransporte_Multa.Text = "Controle";
            this.rbTransporte_Multa.Value = "rbTransporte_Multa";
            this.rbTransporte_Multa.Click += new System.EventHandler(this.rbTransporte_Multa_Click);
            // 
            // rbTransporte_Gravidade
            // 
            this.rbTransporte_Gravidade.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Gravidade.Image")));
            this.rbTransporte_Gravidade.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Gravidade.SmallImage")));
            this.rbTransporte_Gravidade.Text = "Gravidades";
            this.rbTransporte_Gravidade.Value = "rbTransporte_Gravidade";
            this.rbTransporte_Gravidade.Click += new System.EventHandler(this.rbTransporte_Gravidade_Click);
            // 
            // rbTransporte_Ocorrencia
            // 
            this.rbTransporte_Ocorrencia.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Ocorrencia.Image")));
            this.rbTransporte_Ocorrencia.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Ocorrencia.SmallImage")));
            this.rbTransporte_Ocorrencia.Text = "Ocorrências";
            this.rbTransporte_Ocorrencia.Value = "rbTransporte_Ocorrencia";
            this.rbTransporte_Ocorrencia.Click += new System.EventHandler(this.rbTransporte_Ocorrencia_Click);
            // 
            // ribbonPanel10
            // 
            this.ribbonPanel10.Items.Add(this.rbTransporte_Uso);
            this.ribbonPanel10.Text = "Uso dos Veículos";
            // 
            // rbTransporte_Uso
            // 
            this.rbTransporte_Uso.Image = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Uso.Image")));
            this.rbTransporte_Uso.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbTransporte_Uso.SmallImage")));
            this.rbTransporte_Uso.Text = "Controle";
            this.rbTransporte_Uso.Value = "rbTransporte_Uso";
            this.rbTransporte_Uso.Click += new System.EventHandler(this.rbTransporte_Uso_Click);
            // 
            // rtAdministrativo
            // 
            this.rtAdministrativo.Panels.Add(this.ribbonPanel3);
            this.rtAdministrativo.Text = "Administrativo";
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.Items.Add(this.rbAdministrativo_Clientes);
            this.ribbonPanel3.Items.Add(this.ribbonSeparator7);
            this.ribbonPanel3.Items.Add(this.rbAdministrativo_Fornecedores);
            this.ribbonPanel3.Items.Add(this.ribbonSeparator13);
            this.ribbonPanel3.Items.Add(this.rbAdministrativo_Atividades);
            this.ribbonPanel3.Items.Add(this.ribbonSeparator8);
            this.ribbonPanel3.Items.Add(this.rbAdministrativo_Categorias);
            this.ribbonPanel3.Items.Add(this.ribbonSeparator11);
            this.ribbonPanel3.Items.Add(this.rbAdministrativo_Feriados);
            this.ribbonPanel3.Items.Add(this.ribbonSeparator18);
            this.ribbonPanel3.Items.Add(this.rbAdministrativo_Empresa);
            this.ribbonPanel3.Text = "Cadastros";
            // 
            // rbAdministrativo_Clientes
            // 
            this.rbAdministrativo_Clientes.Image = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Clientes.Image")));
            this.rbAdministrativo_Clientes.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Clientes.SmallImage")));
            this.rbAdministrativo_Clientes.Text = "Clientes";
            this.rbAdministrativo_Clientes.Value = "rbAdministrativo_Clientes";
            this.rbAdministrativo_Clientes.Click += new System.EventHandler(this.rbAdministrativo_Clientes_Click);
            // 
            // rbAdministrativo_Fornecedores
            // 
            this.rbAdministrativo_Fornecedores.Image = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Fornecedores.Image")));
            this.rbAdministrativo_Fornecedores.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Fornecedores.SmallImage")));
            this.rbAdministrativo_Fornecedores.Text = "Fornecedores";
            this.rbAdministrativo_Fornecedores.Value = "rbAdministrativo_Fornecedores";
            this.rbAdministrativo_Fornecedores.Click += new System.EventHandler(this.rbAdministrativo_Fornecedores_Click);
            // 
            // rbAdministrativo_Atividades
            // 
            this.rbAdministrativo_Atividades.DropDownItems.Add(this.ribbonButton2);
            this.rbAdministrativo_Atividades.Image = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Atividades.Image")));
            this.rbAdministrativo_Atividades.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Atividades.SmallImage")));
            this.rbAdministrativo_Atividades.Text = "Atividades";
            this.rbAdministrativo_Atividades.Value = "rbAdministrativo_Atividades";
            this.rbAdministrativo_Atividades.Click += new System.EventHandler(this.rbAdministrativo_Atividades_Click);
            // 
            // ribbonButton2
            // 
            this.ribbonButton2.Image = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.Image")));
            this.ribbonButton2.SmallImage = ((System.Drawing.Image)(resources.GetObject("ribbonButton2.SmallImage")));
            this.ribbonButton2.Text = "ribbonButton2";
            // 
            // rbAdministrativo_Categorias
            // 
            this.rbAdministrativo_Categorias.Image = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Categorias.Image")));
            this.rbAdministrativo_Categorias.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Categorias.SmallImage")));
            this.rbAdministrativo_Categorias.Text = "Categorias";
            this.rbAdministrativo_Categorias.Value = "rbAdministrativo_Categorias";
            this.rbAdministrativo_Categorias.Click += new System.EventHandler(this.rbAdministrativo_Categorias_Click);
            // 
            // rbAdministrativo_Feriados
            // 
            this.rbAdministrativo_Feriados.Image = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Feriados.Image")));
            this.rbAdministrativo_Feriados.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Feriados.SmallImage")));
            this.rbAdministrativo_Feriados.Text = "Feriados";
            this.rbAdministrativo_Feriados.Value = "rbAdministrativo_Feriados";
            this.rbAdministrativo_Feriados.Click += new System.EventHandler(this.rbAdministrativo_Feriados_Click);
            // 
            // rbAdministrativo_Empresa
            // 
            this.rbAdministrativo_Empresa.Image = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Empresa.Image")));
            this.rbAdministrativo_Empresa.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbAdministrativo_Empresa.SmallImage")));
            this.rbAdministrativo_Empresa.Text = "Empresas";
            this.rbAdministrativo_Empresa.Value = "rbAdministrativo_Empresa";
            this.rbAdministrativo_Empresa.Click += new System.EventHandler(this.rbAdministrativo_Empresa_Click);
            // 
            // rtSeguranca
            // 
            this.rtSeguranca.Panels.Add(this.ribbonPanel2);
            this.rtSeguranca.Panels.Add(this.ribbonPanel7);
            this.rtSeguranca.Panels.Add(this.ribbonPanel11);
            this.rtSeguranca.Text = "Segurança";
            // 
            // ribbonPanel2
            // 
            this.ribbonPanel2.Items.Add(this.rbSeguranca_Usuarios);
            this.ribbonPanel2.Text = "Usuários";
            // 
            // rbSeguranca_Usuarios
            // 
            this.rbSeguranca_Usuarios.Image = ((System.Drawing.Image)(resources.GetObject("rbSeguranca_Usuarios.Image")));
            this.rbSeguranca_Usuarios.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbSeguranca_Usuarios.SmallImage")));
            this.rbSeguranca_Usuarios.Text = "Consulta";
            this.rbSeguranca_Usuarios.Value = "rbSeguranca_Usuarios";
            this.rbSeguranca_Usuarios.Click += new System.EventHandler(this.rbSeguranca_Usuarios_Click);
            // 
            // ribbonPanel7
            // 
            this.ribbonPanel7.Items.Add(this.rbSeguranca_Auditoria);
            this.ribbonPanel7.Text = "Auditoria";
            // 
            // rbSeguranca_Auditoria
            // 
            this.rbSeguranca_Auditoria.Image = ((System.Drawing.Image)(resources.GetObject("rbSeguranca_Auditoria.Image")));
            this.rbSeguranca_Auditoria.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbSeguranca_Auditoria.SmallImage")));
            this.rbSeguranca_Auditoria.Text = "Consulta";
            this.rbSeguranca_Auditoria.Value = "rbSeguranca_Auditoria";
            this.rbSeguranca_Auditoria.Click += new System.EventHandler(this.rbSeguranca_Auditoria_Click);
            // 
            // ribbonPanel11
            // 
            this.ribbonPanel11.Items.Add(this.rbSeguranca_Parametrizacao);
            this.ribbonPanel11.Text = "Parametrização";
            // 
            // rbSeguranca_Parametrizacao
            // 
            this.rbSeguranca_Parametrizacao.Image = ((System.Drawing.Image)(resources.GetObject("rbSeguranca_Parametrizacao.Image")));
            this.rbSeguranca_Parametrizacao.SmallImage = ((System.Drawing.Image)(resources.GetObject("rbSeguranca_Parametrizacao.SmallImage")));
            this.rbSeguranca_Parametrizacao.Text = "Manutenção";
            this.rbSeguranca_Parametrizacao.Value = "rbSeguranca_Parametrizacao";
            this.rbSeguranca_Parametrizacao.Click += new System.EventHandler(this.rbSeguranca_Parametrizacao_Click);
            // 
            // tabTelas
            // 
            this.tabTelas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabTelas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tabTelas.Location = new System.Drawing.Point(0, 135);
            this.tabTelas.Name = "tabTelas";
            this.tabTelas.SelectedIndex = 0;
            this.tabTelas.ShowToolTips = true;
            this.tabTelas.Size = new System.Drawing.Size(1237, 318);
            this.tabTelas.TabIndex = 7;
            this.tabTelas.DoubleClick += new System.EventHandler(this.tabTelas_DoubleClick);
            // 
            // atividadeCarregarComponenteCrystal
            // 
            this.atividadeCarregarComponenteCrystal.DoWork += new System.ComponentModel.DoWorkEventHandler(this.atividadeCarregarComponenteCrystal_DoWork);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsUsuario});
            this.statusStrip.Location = new System.Drawing.Point(0, 431);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1237, 22);
            this.statusStrip.TabIndex = 9;
            this.statusStrip.Text = "statusStrip1";
            // 
            // tsUsuario
            // 
            this.tsUsuario.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsUsuario.Name = "tsUsuario";
            this.tsUsuario.Size = new System.Drawing.Size(0, 17);
            // 
            // mdiBRGS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1237, 453);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.tabTelas);
            this.Controls.Add(this.ribbon1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "mdiBRGS";
            this.Text = "BRGS";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.mdiBRGS_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.Ribbon ribbon1;
        private System.Windows.Forms.RibbonTab rtFinanceiro;
        private System.Windows.Forms.RibbonPanel ribbonPanel1;
        private System.Windows.Forms.RibbonButton rbFinanceiro_NFConsulta;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator1;
        private System.Windows.Forms.RibbonButton ribbonButton1;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator2;
        private System.Windows.Forms.RibbonButton rbFinanceiro_NFEmissao;
        private System.Windows.Forms.RibbonTab ribbonTab2;
        public System.Windows.Forms.TabControl tabTelas;
        private System.Windows.Forms.RibbonTab rtEngenharia;
        private System.Windows.Forms.RibbonPanel rpEngenharia_LancamentoGastos;
        private System.Windows.Forms.RibbonButton rbEngenharia_Obras_Consulta;
        private System.Windows.Forms.RibbonPanel rpEngenharia_Cadastros;
        private System.Windows.Forms.RibbonButton rbEngenharia_Despesas;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator3;
        private System.Windows.Forms.RibbonButton rbEngenharia_CentrosCustos;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator4;
        private System.Windows.Forms.RibbonButton rbEngenharia_UEN;
        private System.Windows.Forms.RibbonTab rtAdministrativo;
        private System.Windows.Forms.RibbonPanel ribbonPanel3;
        private System.Windows.Forms.RibbonButton rbAdministrativo_Clientes;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator5;
        private System.Windows.Forms.RibbonButton rbFinanceiro_NFRelatorio;
        private System.Windows.Forms.RibbonPanel ribbonPanel4;
        private System.Windows.Forms.RibbonButton rbFinanceiro_OPConsulta;
        private System.ComponentModel.BackgroundWorker atividadeCarregarComponenteCrystal;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator6;
        private System.Windows.Forms.RibbonButton rbEngenharia_Obras_Relatorio;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel tsUsuario;
        private System.Windows.Forms.RibbonTab rtSeguranca;
        private System.Windows.Forms.RibbonPanel ribbonPanel2;
        private System.Windows.Forms.RibbonButton rbSeguranca_Usuarios;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator7;
        private System.Windows.Forms.RibbonButton rbAdministrativo_Atividades;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator8;
        private System.Windows.Forms.RibbonButton rbAdministrativo_Categorias;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator9;
        private System.Windows.Forms.RibbonButton rbEngenharia_Fases;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator10;
        private System.Windows.Forms.RibbonButton rbFinanceiro_OPRelatorio;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator11;
        private System.Windows.Forms.RibbonButton rbAdministrativo_Feriados;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator12;
        private System.Windows.Forms.RibbonButton rbFinanceiro_RelatorioGastos;
        private System.Windows.Forms.RibbonButton ribbonButton2;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator13;
        private System.Windows.Forms.RibbonButton rbAdministrativo_Fornecedores;
        private System.Windows.Forms.RibbonPanel ribbonPanel5;
        private System.Windows.Forms.RibbonButton rbTransporte_Veiculo;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator14;
        private System.Windows.Forms.RibbonButton rbTransporte_Motorista;
        private System.Windows.Forms.RibbonPanel ribbonPanel6;
        private System.Windows.Forms.RibbonButton rbTransporte_Abastecimento;
        private System.Windows.Forms.RibbonPanel ribbonPanel7;
        private System.Windows.Forms.RibbonButton rbSeguranca_Auditoria;
        private System.Windows.Forms.RibbonPanel rpTransporte_Frete;
        private System.Windows.Forms.RibbonButton rbTransporte_Frete;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator15;
        private System.Windows.Forms.RibbonButton rbTransporte_FreteRelatorio;
        private System.Windows.Forms.RibbonPanel ribbonPanel8;
        private System.Windows.Forms.RibbonButton rbTransporte_Manutencao;
        private System.Windows.Forms.RibbonPanel ribbonPanel9;
        private System.Windows.Forms.RibbonButton rbTransporte_Multa;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator16;
        private System.Windows.Forms.RibbonButton rbTransporte_Gravidade;
        private System.Windows.Forms.RibbonPanel ribbonPanel10;
        private System.Windows.Forms.RibbonButton rbTransporte_Uso;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator17;
        private System.Windows.Forms.RibbonButton rbTransporte_Ocorrencia;
        private System.Windows.Forms.RibbonPanel ribbonPanel11;
        private System.Windows.Forms.RibbonButton rbSeguranca_Parametrizacao;
        private System.Windows.Forms.RibbonSeparator ribbonSeparator18;
        private System.Windows.Forms.RibbonButton rbAdministrativo_Empresa;
        
    }
}



